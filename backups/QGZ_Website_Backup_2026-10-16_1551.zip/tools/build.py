"""
Queen's Gambit Zürich · build the German site and the legal pages.

    python3 tools/build.py

English is the source: edit en/index.html (and the legal texts in this file),
then run the build. It needs Python 3 and Node.js (for the event data). It writes:

    index.html                 German home page (en/index.html + i18n/de.json)
    impressum/, datenschutz/   legal pages (DE)   en/impressum/, en/privacy/ (EN)
    winz/, en/winz/            registration pages
    kids/zollikon/, en/kids/zollikon/   Kids Chess workshop registration
    sitemap.xml                all pages with hreflang alternates
    and, in en/index.html and the pages above, the upcoming events for search
    engines and visitors without JavaScript (between the @events markers).

The build stops if any English text in en/index.html has no German translation.
"""
import json, pathlib, re, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
from i18n_text import TOKEN, ATTR_RE, TRANSLATABLE_META, norm, has_words  # noqa: E402

SITE = "https://queensgambitzurich.ch"
EMAIL = "info@queensgambitzurich.ch"


# --------------------------------------------------------------------------
# 0. Upcoming events written into the HTML (search engines, AI tools and
#    visitors without JavaScript). Same data and function as the website
#    (data/events.js, js/event-schema.js), run with Node.js.
# --------------------------------------------------------------------------
import html as _html, subprocess, datetime  # noqa: E402

def zurich_today():
    try:
        from zoneinfo import ZoneInfo
        return datetime.datetime.now(ZoneInfo("Europe/Zurich")).date().isoformat()
    except Exception:
        return datetime.date.today().isoformat()

TODAY = zurich_today()

def event_data(lang, only=None, page_url=None):
    args = ["node", str(ROOT / "tools" / "events_data.js"), lang, TODAY] + ([only, page_url] if only else [])
    try:
        return json.loads(subprocess.run(args, check=True, capture_output=True, text=True).stdout)
    except FileNotFoundError:
        sys.exit("Node.js is needed for the event data: install it from https://nodejs.org/ and run the build again.")

def ld_script(graph, scope):
    data = json.dumps({"@context": "https://schema.org", "@graph": graph}, ensure_ascii=False, indent=1)
    return f'<script type="application/ld+json" id="qgz-events-ld" data-scope="{scope}">\n{data}\n</script>'

NOSCRIPT_INTRO = {"en": "Upcoming dates:", "de": "Nächste Termine:"}

def noscript_list(items, lang):
    rows = "\n".join(
        f'          <li><strong>{_html.escape(i["date"])}{" · " + _html.escape(i["time"]) if i["time"] else ""}</strong> · '
        f'{_html.escape(i["title"])} · {_html.escape(i["place"])}</li>' for i in items)
    return (f'<noscript>\n        <p class="event-empty">{NOSCRIPT_INTRO[lang]}</p>\n'
            f'        <ul class="event-noscript">\n{rows}\n        </ul>\n      </noscript>')

def strip_regions(html):
    """Generated regions back to plain markers (before translating)."""
    return re.sub(r"<!-- @(events-[a-z]+):start -->.*?<!-- @\1:end -->", r"<!-- @\1 -->", html, flags=re.S)

def fill_regions(html, lang):
    data = event_data(lang)
    parts = {"events-ld": ld_script(data["schema"], "list") if data["schema"] else "",
             "events-noscript": noscript_list(data["list"], lang) if data["list"] else ""}
    def sub(m):
        key = m.group(1)
        return f"<!-- @{key}:start -->{parts[key]}<!-- @{key}:end -->"
    html = strip_regions(html)
    return re.sub(r"<!-- @(events-[a-z]+)(?:: [^>]*)? -->", sub, html)

# --------------------------------------------------------------------------
# 1. German home page
# --------------------------------------------------------------------------
def translate_html(html, strings, keep):
    missing = []

    def tr_text(raw):
        n = norm(raw)
        if not has_words(n) or n in keep:
            return raw
        if n not in strings:
            missing.append(n)
            return raw
        lead = raw[: len(raw) - len(raw.lstrip())]
        trail = raw[len(raw.rstrip()):]
        return lead + strings[n] + trail

    def tr_tag(tag):
        def sub(m):
            name, val = m.group(1), m.group(2)
            if name == "content":
                meta = re.search(r'\b(?:name|property)="([^"]+)"', tag)
                if not meta or meta.group(1) not in TRANSLATABLE_META:
                    return m.group(0)
            if not has_words(val) or val in keep:
                return m.group(0)
            if val not in strings:
                missing.append(val)
                return m.group(0)
            return f'{name}="{strings[val]}"'
        return ATTR_RE.sub(sub, tag)

    out = []
    for part in TOKEN.split(html):
        if not part:
            continue
        if part.startswith("<!--") or part.lower().startswith(("<script", "<style")):
            out.append(part)
        elif part.startswith("<"):
            out.append(tr_tag(part))
        else:
            out.append(tr_text(part))
    return "".join(out), sorted(set(missing))


def set_lang_switch(html, current, en_href, de_href):
    def fix(m):
        lang = m.group(1)
        tag = m.group(0)
        tag = re.sub(r'\shref="[^"]*"', f' href="{en_href if lang == "en" else de_href}"', tag)
        tag = tag.replace(' aria-current="page"', "")
        if lang == current:
            tag = tag.replace(f'data-lang-link="{lang}"', f'data-lang-link="{lang}" aria-current="page"')
        return tag
    return re.sub(r'<a class="lang-switch__link" data-lang-link="(en|de)"[^>]*>', fix, html)


def build_home_de():
    src = strip_regions((ROOT / "en" / "index.html").read_text())
    data = json.loads((ROOT / "i18n" / "de.json").read_text())
    html, missing = translate_html(src, data["strings"], set(data["_keep"]))
    if missing:
        sys.exit("Missing German translations in i18n/de.json:\n  - " + "\n  - ".join(missing))

    html = html.replace('<html lang="en">', '<html lang="de">', 1)
    # assets are shared with the English site
    html = re.sub(r'\b(src|href)="(assets|css|data|js)/', r'\1="/\2/', html)
    html = html.replace('<link rel="canonical" href="https://queensgambitzurich.ch/en/">',
                        '<link rel="canonical" href="https://queensgambitzurich.ch/">')
    html = html.replace('<meta property="og:url" content="https://queensgambitzurich.ch/en/">',
                        '<meta property="og:url" content="https://queensgambitzurich.ch/">')
    html = html.replace('<meta property="og:locale" content="en_GB">\n<meta property="og:locale:alternate" content="de_CH">',
                        '<meta property="og:locale" content="de_CH">\n<meta property="og:locale:alternate" content="en_GB">')
    html = html.replace('"inLanguage": "en"', '"inLanguage": "de"')
    html = html.replace(
        '"description": "Women\'s chess club and community in Zürich: regular meetings and coaching for all levels, plus Kids Chess, our educational programme for children."',
        '"description": "Schachclub und Community für Frauen in Zürich: regelmässige Treffs und Coaching für alle Spielstärken, dazu Kids Chess, unser Bildungsprogramm für Kinder."')
    html = html.replace('"slogan": "A place for women to play chess."', '"slogan": "Ein Ort, an dem Frauen Schach spielen."')
    html = html.replace('href="/en/privacy/"', 'href="/datenschutz/"')
    html = html.replace('href="/en/impressum/"', 'href="/impressum/"')
    html = set_lang_switch(html, "de", "/en/", "/")
    html = html.replace("<!-- ======================================================================\n     Queen's Gambit Zürich · Website v1",
                        "<!-- GENERATED by tools/build.py from en/index.html + i18n/de.json. Do not edit this file directly. -->\n"
                        "<!-- ======================================================================\n     Queen's Gambit Zürich · Website v1", 1)
    html = fill_regions(html, "de")
    (ROOT / "index.html").write_text(html)
    return html


# --------------------------------------------------------------------------
# 2. Legal pages (EN + DE)
# --------------------------------------------------------------------------
LEGAL = {
    "en": {
        "impressum": {"slug": "en/impressum", "title": "Impressum", "lead": "Information about the operator of this website.",
                      "description": "Impressum of Queen's Gambit Zürich, a women's chess club and community in Zürich, Switzerland."},
        "privacy": {"slug": "en/privacy", "title": "Privacy Policy", "lead": "How we handle data on this website.",
                    "description": "Privacy policy of Queen's Gambit Zürich: no cookies, privacy-friendly visitor statistics; how registrations and the newsletter are handled under the Swiss FADP."},
        "eyebrow": "Legal", "updated": "Last updated", "home": "/en/",
    },
    "de": {
        "impressum": {"slug": "impressum", "title": "Impressum", "lead": "Angaben zur Betreiberin dieser Website.",
                      "description": "Impressum von Queen's Gambit Zürich, Schachclub und Community für Frauen in Zürich."},
        "privacy": {"slug": "datenschutz", "title": "Datenschutzerklärung", "lead": "Wie wir mit Daten auf dieser Website umgehen.",
                    "description": "Datenschutzerklärung von Queen's Gambit Zürich: keine Cookies, datenschutzfreundliche Besucherstatistik; wie Anmeldungen und der Newsletter gemäss DSG bearbeitet werden."},
        "eyebrow": "Rechtliches", "updated": "Zuletzt aktualisiert", "home": "/",
    },
}

IMPRESSUM = {
    "en": f"""
        <h2>Website operator</h2>
        <p>Queen's Gambit Zürich<br>A community project based in Zürich, Switzerland</p>

        <h2>Responsible person</h2>
        <p>Adela Ioana Popon</p>

        <h2>Contact</h2>
        <p>Email: <span class="legal__email">{EMAIL}</span><br>
        Instagram: <a href="https://www.instagram.com/queensgambitzurich/" target="_blank" rel="noopener">@queensgambitzurich</a></p>

        <h2>Participation and fees</h2>
        <p>Queen's Gambit Zürich is a community offering free chess gatherings. Participation in regular community events is free of charge. Certain special events, workshops, tournaments or educational programmes may require a participation fee.</p>

        <h2>Liability for content</h2>
        <p>We prepare the information on this website with care. However, we cannot guarantee that it is always complete, accurate or up to date. Event details may change; if in doubt, please contact us.</p>

        <h2>External links</h2>
        <p>This website contains links to external websites, such as Instagram. We have no influence over their content, and their operators are responsible for it.</p>

        <h2>Copyright</h2>
        <p>The texts, photographs, logos and illustrations on this website belong to Queen's Gambit Zürich unless stated otherwise. Please ask us before reusing them. The fonts Archivo Black, Inter and League Spartan are used under the SIL Open Font License, Version 1.1.</p>

        <p class="legal__updated">Last updated: 8 October 2026</p>
""",
    "de": f"""
        <h2>Betreiberin der Website</h2>
        <p>Queen's Gambit Zürich<br>Ein Community-Projekt mit Sitz in Zürich, Schweiz</p>

        <h2>Verantwortliche Person</h2>
        <p>Adela Ioana Popon</p>

        <h2>Kontakt</h2>
        <p>E-Mail: <span class="legal__email">{EMAIL}</span><br>
        Instagram: <a href="https://www.instagram.com/queensgambitzurich/" target="_blank" rel="noopener">@queensgambitzurich</a></p>

        <h2>Teilnahme und Kosten</h2>
        <p>Queen's Gambit Zürich ist eine Community, die kostenlose Schachtreffen anbietet. Die Teilnahme an den regelmässigen Community-Anlässen ist kostenlos. Für bestimmte Spezialanlässe, Workshops, Turniere oder Bildungsprogramme kann ein Teilnahmebeitrag erhoben werden.</p>

        <h2>Haftung für Inhalte</h2>
        <p>Wir erstellen die Informationen auf dieser Website mit Sorgfalt. Wir können jedoch nicht garantieren, dass sie jederzeit vollständig, richtig und aktuell sind. Angaben zu Anlässen können sich ändern; im Zweifelsfall kontaktiere uns bitte.</p>

        <h2>Externe Links</h2>
        <p>Diese Website enthält Links zu externen Websites, zum Beispiel zu Instagram. Auf deren Inhalte haben wir keinen Einfluss; dafür sind die jeweiligen Betreiber verantwortlich.</p>

        <h2>Urheberrecht</h2>
        <p>Die Texte, Fotos, Logos und Illustrationen auf dieser Website gehören Queen's Gambit Zürich, sofern nicht anders angegeben. Bitte frag uns, bevor du sie weiterverwendest. Die Schriften Archivo Black, Inter und League Spartan werden unter der SIL Open Font License, Version 1.1, verwendet.</p>

        <p class="legal__updated">Zuletzt aktualisiert: 8. Oktober 2026</p>
""",
}

PRIVACY = {
    "en": f"""
        <p>This privacy policy explains how personal data is processed when you visit this website, register for an event, subscribe to our newsletter or contact us. It follows the Swiss Federal Act on Data Protection (FADP).</p>

        <h2>1. Who is responsible</h2>
        <p>Queen's Gambit Zürich, a community project based in Zürich, Switzerland.<br>
        Responsible person: Adela Ioana Popon<br>
        Email: <span class="legal__email">{EMAIL}</span></p>

        <h2>2. In short</h2>
        <p>This website is mainly informational. It has no user accounts. The only personal data we ask for is in the registration form for selected events (section 5) and in the newsletter form (section 6), both of which you use voluntarily. The website uses no cookies. To see how many people visit it, we use GoatCounter, a privacy-friendly visitor statistics service that stores no personal data (section 3). The website does not embed content from social networks. Fonts, images and scripts are delivered from this website itself.</p>

        <h2>3. Hosting, technical data and visitor statistics</h2>
        <p>This website is hosted on GitHub Pages, a service of GitHub, Inc., USA. When you visit the website, your browser connects to GitHub's servers, which necessarily process technical data such as your IP address, the date and time of the request and your browser type in order to deliver the pages. According to GitHub, visitors' IP addresses are logged and stored for security purposes. We do not receive or analyse this data ourselves.</p>
        <p>GitHub processes this data in the USA. GitHub participates in the Swiss-U.S. Data Privacy Framework, under which Switzerland recognises an adequate level of data protection for certified US companies. For details, see the <a href="https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement" target="_blank" rel="noopener">GitHub General Privacy Statement</a>.</p>
        <p>To see how many people visit the website and which pages are read, we use GoatCounter, a visitor statistics service operated by Martin Tournoij, Ireland, with servers at Hetzner Online GmbH in Germany and Finland. When a page loads, your browser sends GoatCounter the address and title of the page, the page you came from or a campaign parameter in the link (for example from our newsletter), and your screen width; GoatCounter's server also receives your IP address and your browser identification. GoatCounter does not store your IP address or the full browser identification: it derives only your country, browser and operating system and keeps statistics that do not identify you. To recognise repeat page views, it keeps a random identifier in memory for up to 8 hours. GoatCounter sets no cookies and stores nothing in your browser. We only see the statistics; they do not allow us to identify you. Switzerland recognises the EU as having an adequate level of data protection. For details, see the <a href="https://www.goatcounter.com/help/privacy" target="_blank" rel="noopener">GoatCounter privacy policy</a>.</p>

        <h2>4. Contacting us by email</h2>
        <p>You can contact us at <span class="legal__email">{EMAIL}</span>. This mailbox is provided by GoDaddy (GoDaddy Operating Company, LLC, USA). We also use <span class="legal__email">queensgambitzurich@gmail.com</span>, a Gmail account provided by Google; we may reply from this address.</p>
        <p>When you email us, we process your email address, your name if you give it, the content of your message and any attachments, and the technical information that comes with every email, such as the date and time. We use this information only to answer your message and to deal with your request, for example a question about one of our events. We do not use it for advertising or newsletters, and we do not pass it on to anyone else.</p>
        <p>Your messages are stored on the servers of GoDaddy and Google, which may process them in the USA and other countries. Both GoDaddy and Google participate in the Swiss-U.S. Data Privacy Framework. We delete emails when they are no longer needed for the purpose for which you sent them.</p>

        <h2>5. Registering for an event</h2>
        <p>For selected events, such as QGZ × WINZ, you can register on this website. We then process your full name, your email address, your participation type, your Elo rating if you choose to give it, the language of the form and the date and time of your registration.</p>
        <p>We use this data only to manage your registration: to confirm it, to plan the event (for example the blitz tournament pairings) and to email you about this event. We do not use it for advertising or newsletters, and we do not pass it on to anyone else. Only the QGZ organisers have access.</p>
        <p>For Kids Chess workshops, such as Zollikon Kids Chess, a parent or guardian registers the child. We then process the parent’s or guardian’s first and last name, email address and phone number; the child’s first and last name, date of birth, chess experience and the languages the child speaks; any allergies, intolerances or dietary requirements you tell us about; your choice on photos for the Chess Passport; any additional information you give; the sessions booked, the applicable price, a waiting-list status if applicable and the payment status; the language of the form and the date and time of the registration. We use the allergy and dietary information only to keep the child safe during the workshop, the phone number only to reach you about the workshop, for example on the day itself. If you also tick the optional box for emails about future Kids Chess workshops and activities, we record this consent with the registration and keep your name and email address for that purpose until you withdraw it; this does not subscribe you to our newsletter.</p>
        <p>The form sends your details to a Google Apps Script service in our Google account. Your registration is stored in a private Google Sheets spreadsheet, and the confirmation emails are sent via Google. When you submit the form, your browser connects to Google's servers, which also process your IP address. Google LLC may process this data in the USA and participates in the Swiss-U.S. Data Privacy Framework. To protect the form against spam, we use a hidden check field and a timing check; no cookies or tracking are involved.</p>
        <p>You register by ticking the consent box. You can withdraw your consent and cancel your registration at any time by emailing <span class="legal__email">{EMAIL}</span>; we then delete your registration. Otherwise we delete registrations no later than three months after the event.</p>

        <h2>6. Newsletter</h2>
        <p>You can subscribe to our newsletter on this website. We then process your email address, the topics you choose (Women's Chess Club &amp; Community, Kids Chess, General QGZ news and events), the language of the form, the date and time of your subscription, and the date, time and IP address of your confirmation, which serve as proof of your consent.</p>
        <p>We send the newsletter with Mailchimp, a service of The Rocket Science Group LLC d/b/a Mailchimp (Intuit), USA. Your data is stored in our Mailchimp account and may be processed in the USA. Mailchimp participates in the Swiss-U.S. Data Privacy Framework. When you submit the form, your details are sent to a Google Apps Script service in our Google account, which passes them on to Mailchimp and does not store them. Google LLC may process this data, including your IP address, in the USA and participates in the Swiss-U.S. Data Privacy Framework. No Mailchimp script is loaded with this website and no cookies are set on it.</p>
        <p>We use double opt-in: after subscribing, you receive an email with a confirmation link, and you are subscribed only once you click it. We use your data only to send you the newsletter on the topics you chose. Mailchimp shows us whether a newsletter was opened and which links were clicked, so that we can improve our emails. We do not pass your data on to anyone else for their own purposes.</p>
        <p>Subscribing is voluntary and based on your consent. You can unsubscribe at any time with the link at the bottom of every newsletter, change your topics there, or write to <span class="legal__email">{EMAIL}</span>. We then stop sending you newsletters. Registering for an event does not subscribe you to the newsletter.</p>

        <h2>7. Links to other websites</h2>
        <p>Our website links to our Instagram profile, partner websites such as WINZ and other external websites. No data is sent to these services when you visit our website; it is only when you follow a link that you leave our website, and the privacy policy of that provider applies, for Instagram that of Meta Platforms.</p>

        <h2>8. Your rights</h2>
        <p>Under the FADP you can ask us for information about personal data we process about you, and you can request its correction or deletion. Please write to <span class="legal__email">{EMAIL}</span>. You can also contact the Swiss Federal Data Protection and Information Commissioner (FDPIC) at <a href="https://www.edoeb.admin.ch" target="_blank" rel="noopener">edoeb.admin.ch</a>.</p>

        <h2>9. Changes</h2>
        <p>We will update this privacy policy if the website or the way we process data changes. The current version is always published on this page.</p>

        <p class="legal__updated">Last updated: 15 October 2026</p>
""",
    "de": f"""
        <p>Diese Datenschutzerklärung erklärt, wie Personendaten bearbeitet werden, wenn du diese Website besuchst, dich für einen Anlass anmeldest, unseren Newsletter abonnierst oder uns kontaktierst. Sie richtet sich nach dem Schweizer Bundesgesetz über den Datenschutz (DSG).</p>

        <h2>1. Verantwortlich</h2>
        <p>Queen's Gambit Zürich, ein Community-Projekt mit Sitz in Zürich, Schweiz.<br>
        Verantwortliche Person: Adela Ioana Popon<br>
        E-Mail: <span class="legal__email">{EMAIL}</span></p>

        <h2>2. Kurz zusammengefasst</h2>
        <p>Diese Website dient hauptsächlich der Information. Es gibt keine Benutzerkonten. Personendaten erfragen wir nur im Anmeldeformular für ausgewählte Anlässe (Abschnitt 5) und im Newsletter-Formular (Abschnitt 6), die du beide freiwillig nutzt. Die Website verwendet keine Cookies. Um zu sehen, wie viele Personen sie besuchen, verwenden wir GoatCounter, einen datenschutzfreundlichen Dienst für Besucherstatistiken, der keine Personendaten speichert (Abschnitt 3). Die Website bindet keine Inhalte sozialer Netzwerke ein. Schriften, Bilder und Skripte werden direkt von dieser Website geladen.</p>

        <h2>3. Hosting, technische Daten und Besucherstatistik</h2>
        <p>Diese Website wird bei GitHub Pages gehostet, einem Dienst der GitHub, Inc., USA. Wenn du die Website besuchst, verbindet sich dein Browser mit den Servern von GitHub. Dabei werden zwangsläufig technische Daten wie deine IP-Adresse, Datum und Uhrzeit der Anfrage und dein Browsertyp bearbeitet, damit die Seiten ausgeliefert werden können. Gemäss GitHub werden die IP-Adressen der Besucherinnen und Besucher aus Sicherheitsgründen protokolliert und gespeichert. Wir selbst erhalten und analysieren diese Daten nicht.</p>
        <p>GitHub bearbeitet diese Daten in den USA. GitHub nimmt am Swiss-U.S. Data Privacy Framework teil, unter dem die Schweiz für zertifizierte US-Unternehmen ein angemessenes Datenschutzniveau anerkennt. Weitere Informationen findest du im <a href="https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement" target="_blank" rel="noopener">GitHub General Privacy Statement</a>.</p>
        <p>Um zu sehen, wie viele Personen die Website besuchen und welche Seiten gelesen werden, verwenden wir GoatCounter, einen Dienst für Besucherstatistiken, der von Martin Tournoij, Irland, betrieben wird; die Server stehen bei der Hetzner Online GmbH in Deutschland und Finnland. Beim Laden einer Seite übermittelt dein Browser GoatCounter die Adresse und den Titel der Seite, die Seite, von der du kommst, oder einen Kampagnenparameter im Link (zum Beispiel aus unserem Newsletter) sowie deine Bildschirmbreite; der Server von GoatCounter erhält zudem deine IP-Adresse und die Kennung deines Browsers. GoatCounter speichert weder deine IP-Adresse noch die vollständige Browserkennung: Abgeleitet werden nur Land, Browser und Betriebssystem, und gespeichert werden Statistiken, die dich nicht identifizieren. Um wiederholte Seitenaufrufe zu erkennen, wird bis zu 8 Stunden lang eine zufällige Kennung im Arbeitsspeicher gehalten. GoatCounter setzt keine Cookies und speichert nichts in deinem Browser. Wir sehen nur die Statistiken; sie erlauben uns nicht, dich zu identifizieren. Die Schweiz anerkennt für die EU ein angemessenes Datenschutzniveau. Weitere Informationen findest du in der <a href="https://www.goatcounter.com/help/privacy" target="_blank" rel="noopener">Datenschutzerklärung von GoatCounter</a>.</p>

        <h2>4. Kontakt per E-Mail</h2>
        <p>Du erreichst uns unter <span class="legal__email">{EMAIL}</span>. Dieses Postfach wird von GoDaddy (GoDaddy Operating Company, LLC, USA) bereitgestellt. Zudem verwenden wir <span class="legal__email">queensgambitzurich@gmail.com</span>, ein Gmail-Konto von Google; es kann sein, dass wir von dieser Adresse aus antworten.</p>
        <p>Wenn du uns schreibst, bearbeiten wir deine E-Mail-Adresse, deinen Namen, sofern du ihn angibst, den Inhalt deiner Nachricht und allfällige Anhänge sowie die technischen Angaben, die jede E-Mail enthält, etwa Datum und Uhrzeit. Wir verwenden diese Angaben nur, um deine Nachricht zu beantworten und dein Anliegen zu bearbeiten, zum Beispiel eine Frage zu einem unserer Anlässe. Wir verwenden sie weder für Werbung noch für Newsletter und geben sie nicht an Dritte weiter.</p>
        <p>Deine Nachrichten werden auf den Servern von GoDaddy und Google gespeichert, die sie in den USA und in anderen Ländern bearbeiten können. GoDaddy und Google nehmen beide am Swiss-U.S. Data Privacy Framework teil. Wir löschen E-Mails, sobald sie für den Zweck, zu dem du sie geschickt hast, nicht mehr benötigt werden.</p>

        <h2>5. Anmeldung für einen Anlass</h2>
        <p>Für ausgewählte Anlässe wie QGZ × WINZ kannst du dich auf dieser Website anmelden. Dabei bearbeiten wir deinen Vor- und Nachnamen, deine E-Mail-Adresse, die Art deiner Teilnahme, deine Elo-Zahl, sofern du sie angibst, die Sprache des Formulars sowie Datum und Uhrzeit deiner Anmeldung.</p>
        <p>Wir verwenden diese Daten nur, um deine Anmeldung zu verwalten: um sie zu bestätigen, den Anlass zu planen (zum Beispiel die Paarungen des Blitzturniers) und dich per E-Mail über diesen Anlass zu informieren. Wir verwenden sie weder für Werbung noch für Newsletter und geben sie nicht an Dritte weiter. Zugriff haben nur die Organisatorinnen und Organisatoren von QGZ.</p>
        <p>Bei Kids-Chess-Workshops wie Zollikon Kids Chess meldet ein Elternteil oder eine erziehungsberechtigte Person das Kind an. Dabei bearbeiten wir Vor- und Nachname, E-Mail-Adresse und Telefonnummer des Elternteils oder der erziehungsberechtigten Person; Vor- und Nachname, Geburtsdatum, Schacherfahrung und gesprochene Sprachen des Kindes; allfällige Allergien, Unverträglichkeiten oder Ernährungsanforderungen, die du uns mitteilst; deine Wahl zu Fotos für den Chess Passport; allfällige weitere Informationen; die gebuchten Termine, den anwendbaren Preis, gegebenenfalls einen Wartelistenstatus und den Zahlungsstatus; die Sprache des Formulars sowie Datum und Uhrzeit der Anmeldung. Die Angaben zu Allergien und Ernährung verwenden wir nur, um die Sicherheit des Kindes während des Workshops zu gewährleisten, die Telefonnummer nur, um dich wegen des Workshops zu erreichen, zum Beispiel am Workshoptag selbst. Wenn du zusätzlich das freiwillige Feld für E-Mails über künftige Kids-Chess-Workshops und -Aktivitäten ankreuzt, halten wir diese Einwilligung bei der Anmeldung fest und bewahren deinen Namen und deine E-Mail-Adresse für diesen Zweck auf, bis du die Einwilligung widerrufst; damit wirst du nicht für unseren Newsletter angemeldet.</p>
        <p>Das Formular übermittelt deine Angaben an einen Google-Apps-Script-Dienst in unserem Google-Konto. Deine Anmeldung wird in einer privaten Google-Sheets-Tabelle gespeichert, und die Bestätigungs-E-Mails werden über Google versendet. Beim Absenden verbindet sich dein Browser mit den Servern von Google, die dabei auch deine IP-Adresse bearbeiten. Google LLC kann diese Daten in den USA bearbeiten und nimmt am Swiss-U.S. Data Privacy Framework teil. Zum Schutz vor Spam verwenden wir ein verstecktes Prüffeld und eine Zeitprüfung; Cookies oder Tracking kommen dabei nicht zum Einsatz.</p>
        <p>Du meldest dich an, indem du das Einwilligungsfeld ankreuzt. Du kannst deine Einwilligung jederzeit widerrufen und deine Anmeldung stornieren, indem du an <span class="legal__email">{EMAIL}</span> schreibst; wir löschen deine Anmeldung dann. Andernfalls löschen wir Anmeldungen spätestens drei Monate nach dem Anlass.</p>

        <h2>6. Newsletter</h2>
        <p>Auf dieser Website kannst du unseren Newsletter abonnieren. Dabei bearbeiten wir deine E-Mail-Adresse, die von dir gewählten Themen (Schachclub &amp; Community für Frauen, Kids Chess, Allgemeine QGZ-News und Anlässe), die Sprache des Formulars, Datum und Uhrzeit deiner Anmeldung sowie Datum, Uhrzeit und IP-Adresse deiner Bestätigung, die als Nachweis deiner Einwilligung dienen.</p>
        <p>Wir versenden den Newsletter mit Mailchimp, einem Dienst der The Rocket Science Group LLC d/b/a Mailchimp (Intuit), USA. Deine Daten werden in unserem Mailchimp-Konto gespeichert und können in den USA bearbeitet werden. Mailchimp nimmt am Swiss-U.S. Data Privacy Framework teil. Beim Absenden werden deine Angaben an einen Google-Apps-Script-Dienst in unserem Google-Konto übermittelt, der sie an Mailchimp weiterleitet und nicht speichert. Google LLC kann diese Daten, einschliesslich deiner IP-Adresse, in den USA bearbeiten und nimmt am Swiss-U.S. Data Privacy Framework teil. Mit dieser Website wird kein Mailchimp-Skript geladen und es werden keine Cookies gesetzt.</p>
        <p>Wir verwenden das Double-Opt-in-Verfahren: Nach der Anmeldung erhältst du eine E-Mail mit einem Bestätigungslink, und erst wenn du darauf klickst, ist dein Abo aktiv. Wir verwenden deine Daten nur, um dir den Newsletter zu den gewählten Themen zu schicken. Mailchimp zeigt uns, ob ein Newsletter geöffnet und welche Links angeklickt wurden, damit wir unsere E-Mails verbessern können. Wir geben deine Daten nicht an Dritte für deren eigene Zwecke weiter.</p>
        <p>Das Abo ist freiwillig und beruht auf deiner Einwilligung. Du kannst dich jederzeit über den Link am Ende jedes Newsletters abmelden, dort deine Themen ändern oder an <span class="legal__email">{EMAIL}</span> schreiben. Wir schicken dir dann keine Newsletter mehr. Eine Anmeldung für einen Anlass meldet dich nicht für den Newsletter an.</p>

        <h2>7. Links zu anderen Websites</h2>
        <p>Unsere Website verlinkt auf unser Instagram-Profil, auf Websites von Partnern wie WINZ und auf weitere externe Websites. Beim Besuch unserer Website werden keine Daten an diese Dienste übermittelt. Erst wenn du einem Link folgst, verlässt du unsere Website; dann gilt die Datenschutzerklärung des jeweiligen Anbieters, bei Instagram diejenige von Meta Platforms.</p>

        <h2>8. Deine Rechte</h2>
        <p>Gemäss DSG kannst du Auskunft über die Personendaten verlangen, die wir über dich bearbeiten, und deren Berichtigung oder Löschung verlangen. Schreib uns dazu an <span class="legal__email">{EMAIL}</span>. Du kannst dich auch an den Eidgenössischen Datenschutz- und Öffentlichkeitsbeauftragten (EDÖB) wenden: <a href="https://www.edoeb.admin.ch" target="_blank" rel="noopener">edoeb.admin.ch</a>.</p>

        <h2>9. Änderungen</h2>
        <p>Wir passen diese Datenschutzerklärung an, wenn sich die Website oder die Bearbeitung von Daten ändert. Die aktuelle Version ist jeweils auf dieser Seite veröffentlicht.</p>

        <p class="legal__updated">Zuletzt aktualisiert: 15. Oktober 2026</p>
""",
}

PAGE = """<!doctype html>
<html lang="{lang}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{title} | Queen's Gambit Zürich</title>
<meta name="description" content="{description}">
<meta name="robots" content="index, follow">
<link rel="canonical" href="{site}/{slug}/">
<link rel="alternate" hreflang="en" href="{site}/{en_slug}/">
<link rel="alternate" hreflang="de" href="{site}/{de_slug}/">
<link rel="alternate" hreflang="x-default" href="{site}/{de_slug}/">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Queen's Gambit Zürich">
<meta property="og:title" content="{title} | Queen's Gambit Zürich">
<meta property="og:description" content="{description}">
<meta property="og:url" content="{site}/{slug}/">
<meta property="og:locale" content="{og_locale}">
<meta property="og:image" content="{site}/assets/brand/qgz-social-1200x630.jpg">
<meta name="theme-color" content="#EAF3FF">
<link rel="icon" href="/favicon.ico" sizes="48x48">
<link rel="icon" type="image/png" sizes="96x96" href="/assets/brand/favicon-96.png">
<link rel="icon" type="image/png" sizes="192x192" href="/assets/brand/favicon-192.png">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
{styles}
</head>
<body>

<!-- GENERATED by tools/build.py (legal page). Edit the text in tools/build.py, then run the build. -->
{header}

<main id="main">
  <section class="section legal" id="top-of-page" aria-labelledby="legal-title">
    <div class="container">
      <header class="section-head">
        <p class="eyebrow">{eyebrow}</p>
        <h1 id="legal-title" class="legal__title">{title}</h1>
        <p class="lead">{lead}</p>
      </header>
      <article class="legal__body">
{body}
      </article>
    </div>
  </section>
</main>

{footer}

<div class="toast" role="status" aria-live="polite" data-toast hidden></div>

{scripts}
</body>
</html>
"""


def shell(home_html, lang, extra_css=()):
    """Shared header, footer, styles and scripts for generated sub-pages."""
    head = re.search(r"<head>(.*?)</head>", home_html, re.S).group(1)
    v = re.search(r"\?v=([0-9-]+)", home_html).group(1)
    styles = "\n".join(re.findall(r'<link rel="(?:preload|stylesheet)"[^>]*>', head))
    styles = re.sub(r'href="(?!/|https?:)', 'href="/', styles)
    styles += "".join(f'\n<link rel="stylesheet" href="/css/{name}.css?v={v}">' for name in extra_css)
    scripts = "\n".join(s for s in re.findall(r'<script src="[^"]*"></script>', home_html))
    scripts = re.sub(r'src="(?!/)', 'src="/', scripts)

    header = re.search(r'(<a class="skip-link".*?</header>)', home_html, re.S).group(1)
    footer = re.search(r"(<!-- 9\. FOOTER.*?</footer>)", home_html, re.S).group(1)
    home = LEGAL[lang]["home"]

    def absolutise(block):
        block = re.sub(r'(href|data-fallback-href)="#(?!main")', r'\1="' + home + '#', block)
        block = block.replace(f'href="{home}#home" aria-label', f'href="{home}" aria-label')
        block = re.sub(r'src="(assets/)', r'src="/\1', block)
        return block

    header = absolutise(header)
    footer = absolutise(footer)
    footer = re.sub(r'href="' + re.escape(home) + r'#home">([^<]+)</a>', r'href="#top-of-page">\1</a>', footer)
    return styles, scripts, header, footer


def legal_pages(home_html, lang):
    styles, scripts, header, footer = shell(home_html, lang, ("legal",))
    for key in ("impressum", "privacy"):
        meta = LEGAL[lang][key]
        en_slug, de_slug = LEGAL["en"][key]["slug"], LEGAL["de"][key]["slug"]
        hdr = set_lang_switch(header, lang, f"/{en_slug}/", f"/{de_slug}/")
        page = PAGE.format(
            lang=lang, site=SITE, slug=meta["slug"], en_slug=en_slug, de_slug=de_slug,
            title=meta["title"], description=meta["description"], lead=meta["lead"],
            og_locale="de_CH" if lang == "de" else "en_GB", eyebrow=LEGAL[lang]["eyebrow"],
            body=(IMPRESSUM if key == "impressum" else PRIVACY)[lang].rstrip(),
            header=hdr, footer=footer, styles=styles, scripts=scripts)
        out = ROOT / meta["slug"] / "index.html"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(page)


# --------------------------------------------------------------------------
# 3. Registration pages: shareable link that opens the form directly
#    /winz/ (EN) and /de/winz/ (DE). The form markup is taken from the
#    (translated) home page dialog, so both stay identical.
# --------------------------------------------------------------------------
REG_PAGES = {
    "winz": {
        "event_id": "chess-club-2026-11-29",
        "event_title": "QGZ × WINZ | Beyond the Chessboard",
        "en": {"slug": "en/winz", "title": "Registration: QGZ × WINZ | Beyond the Chessboard",
               "description": "Free registration for QGZ × WINZ | Beyond the Chessboard on Sunday, 29 November 2026 from 13:00 at ROBIN’S, Zürich."},
        "de": {"slug": "winz", "title": "Anmeldung: QGZ × WINZ | Beyond the Chessboard",
               "description": "Kostenlose Anmeldung für QGZ × WINZ | Beyond the Chessboard am Sonntag, 29. November 2026 ab 13:00 im ROBIN’S, Zürich."},
    },
}

REG_PAGE = """<!doctype html>
<html lang="{lang}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{title} | Queen's Gambit Zürich</title>
<meta name="description" content="{description}">
<meta name="robots" content="index, follow">
<link rel="canonical" href="{site}/{slug}/">
<link rel="alternate" hreflang="en" href="{site}/{en_slug}/">
<link rel="alternate" hreflang="de" href="{site}/{de_slug}/">
<link rel="alternate" hreflang="x-default" href="{site}/{de_slug}/">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Queen's Gambit Zürich">
<meta property="og:title" content="{title}">
<meta property="og:description" content="{description}">
<meta property="og:url" content="{site}/{slug}/">
<meta property="og:locale" content="{og_locale}">
<meta property="og:image" content="{site}/assets/brand/qgz-social-1200x630.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#EAF3FF">
<link rel="icon" href="/favicon.ico" sizes="48x48">
<link rel="icon" type="image/png" sizes="96x96" href="/assets/brand/favicon-96.png">
<link rel="icon" type="image/png" sizes="192x192" href="/assets/brand/favicon-192.png">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
{event_ld}
{styles}
</head>
<body>

<!-- GENERATED by tools/build.py (registration page). The form is copied from the home page dialog; the event comes from data/events.js. -->
{header}

<main id="main">
  <section class="section reg-page" id="top-of-page" data-reg-page data-event-id="{event_id}">
    <div class="container reg-page__inner">
{panel}
      <ol class="event-list reg-page__event" data-reg-event-card></ol>
    </div>
  </section>
</main>

{footer}

<div class="toast" role="status" aria-live="polite" data-toast hidden></div>

{scripts}
</body>
</html>
"""


def registration_pages(home_html, lang):
    styles, scripts, header, footer = shell(home_html, lang)
    dialog = re.search(r'<dialog class="reg-dialog"[^>]*>\n(.*?)\n</dialog>', home_html, re.S).group(1)
    # Same form, shown in the page instead of a pop-up
    dialog = re.sub(r'\s*<button class="reg-dialog__close".*?</button>', "", dialog, count=1, flags=re.S)
    dialog = re.sub(r'\s*<button[^>]*data-reg-close>[^<]*</button>', "", dialog)   # nothing to close
    for key, cfg in REG_PAGES.items():
        meta = cfg[lang]
        en_slug, de_slug = cfg["en"]["slug"], cfg["de"]["slug"]
        panel = dialog.replace('<p class="reg-dialog__title" id="reg-title" role="heading" aria-level="2" data-reg-event-title></p>',
                               f'<h1 class="reg-dialog__title" id="reg-title" data-reg-event-title>{cfg["event_title"]}</h1>')
        panel = f'      <div class="reg-inline" aria-labelledby="reg-title" data-reg-dialog data-reg-inline>\n{panel}\n      </div>'
        hdr = set_lang_switch(header, lang, f"/{en_slug}/", f"/{de_slug}/")
        page = REG_PAGE.format(
            lang=lang, site=SITE, slug=meta["slug"], en_slug=en_slug, de_slug=de_slug,
            title=meta["title"], description=meta["description"], event_id=cfg["event_id"],
            og_locale="de_CH" if lang == "de" else "en_GB",
            event_ld=ld_script(event_data(lang, cfg["event_id"], f"{SITE}/{meta['slug']}/")["schema"], "event"),
            panel=panel, header=hdr, footer=footer, styles=styles, scripts=scripts)
        out = ROOT / meta["slug"] / "index.html"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(page)


# --------------------------------------------------------------------------
# 3b. Kids Chess workshop registration pages: /kids/<workshop>/ (DE) and
#     /en/kids/<workshop>/ (EN). The page content is tools/kids_registration.html
#     (English, translated with i18n/de.json); sessions come from
#     data/events.js and the form posts to the Kids Chess Apps Script
#     (data/config.js → kidsChess.endpoint), separate from WINZ.
# --------------------------------------------------------------------------
KIDS_PAGES = {
    "zollikon": {
        "event_id": "zollikon-kids-chess-pilot-2026",
        "en": {"slug": "en/kids/zollikon", "title": "Registration: Zollikon Kids Chess",
               "description": "Registration for Zollikon Kids Chess: three chess mornings for children aged 5–13 on 24, 25 and 31 October 2026 at Combi Face, Zollikon."},
        "de": {"slug": "kids/zollikon", "title": "Anmeldung: Zollikon Kids Chess",
               "description": "Anmeldung für Zollikon Kids Chess: drei Schachvormittage für Kinder von 5 bis 13 Jahren am 24., 25. und 31. Oktober 2026 im Combi Face, Zollikon."},
    },
}

KIDS_PAGE = REG_PAGE.split("<main id=\"main\">")[0].replace(
    "<!-- GENERATED by tools/build.py (registration page). The form is copied from the home page dialog; the event comes from data/events.js. -->",
    "<!-- GENERATED by tools/build.py (Kids Chess registration page) from tools/kids_registration.html. Do not edit this file directly. -->"
) + """<main id="main">
{content}
</main>

{footer}

<div class="toast" role="status" aria-live="polite" data-toast hidden></div>

{scripts}
</body>
</html>
"""


def kids_pages(home_html, lang):
    styles, scripts, header, footer = shell(home_html, lang, ("kids-registration",))
    v = re.search(r"\?v=([0-9-]+)", home_html).group(1)
    scripts += f'\n<script src="/js/kids-registration.js?v={v}"></script>'
    src = (ROOT / "tools" / "kids_registration.html").read_text()
    src = re.sub(r"^<!--.*?-->\n", "", src, count=1, flags=re.S)       # source note
    if lang == "de":
        data = json.loads((ROOT / "i18n" / "de.json").read_text())
        # Parents are addressed formally ("Sie") on these pages: kids_strings
        # overrides the shared (informal "du") translations.
        src, missing = translate_html(src, {**data["strings"], **data.get("kids_strings", {})}, set(data["_keep"]))
        if missing:
            sys.exit("Missing German translations in i18n/de.json (tools/kids_registration.html):\n  - " + "\n  - ".join(missing))
        src = src.replace('href="/en/privacy/"', 'href="/datenschutz/"')
    for key, cfg in KIDS_PAGES.items():
        meta = cfg[lang]
        en_slug, de_slug = cfg["en"]["slug"], cfg["de"]["slug"]
        hdr = set_lang_switch(header, lang, f"/{en_slug}/", f"/{de_slug}/")
        page = KIDS_PAGE.format(
            lang=lang, site=SITE, slug=meta["slug"], en_slug=en_slug, de_slug=de_slug,
            title=meta["title"], description=meta["description"],
            og_locale="de_CH" if lang == "de" else "en_GB",
            event_ld=ld_script(event_data(lang, cfg["event_id"], f"{SITE}/{meta['slug']}/")["schema"], "event"),
            header=hdr, footer=footer, styles=styles, scripts=scripts,
            content=src.rstrip().replace("{event_id}", cfg["event_id"]))
        out = ROOT / meta["slug"] / "index.html"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(page)


# --------------------------------------------------------------------------
# 4. Sitemap
# --------------------------------------------------------------------------
def sitemap(lastmod):
    pairs = [("en/", "", "weekly", "1.0"),
             ("en/impressum/", "impressum/", "yearly", "0.3"),
             ("en/privacy/", "datenschutz/", "yearly", "0.3"),
             ("en/winz/", "winz/", "weekly", "0.8")] + \
            [(c["en"]["slug"] + "/", c["de"]["slug"] + "/", "weekly", "0.8") for c in KIDS_PAGES.values()]
    rows = []
    for en, de, freq, prio in pairs:
        for loc in (de, en):
            rows.append(f"""  <url>
    <loc>{SITE}/{loc}</loc>
    <xhtml:link rel="alternate" hreflang="en" href="{SITE}/{en}"/>
    <xhtml:link rel="alternate" hreflang="de" href="{SITE}/{de}"/>
    <xhtml:link rel="alternate" hreflang="x-default" href="{SITE}/{de}"/>
    <lastmod>{lastmod}</lastmod>
    <changefreq>{freq}</changefreq>
    <priority>{prio}</priority>
  </url>""")
    (ROOT / "sitemap.xml").write_text('<?xml version="1.0" encoding="UTF-8"?>\n'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">\n'
        + "\n".join(rows) + "\n</urlset>\n")


# --------------------------------------------------------------------------
# 5. Redirects for addresses used before German became the default
#    (13 Oct 2026). GitHub Pages has no server redirects, so each old address
#    gets a tiny page that forwards to the new one.
# --------------------------------------------------------------------------
REDIRECTS = {
    "de": "/", "de/impressum": "/impressum/", "de/datenschutz": "/datenschutz/",
    "de/winz": "/winz/", "privacy": "/en/privacy/",
}
REDIRECT_PAGE = """<!doctype html>
<html lang="de">
<head>
<meta charset="utf-8">
<title>Queen's Gambit Zürich</title>
<meta name="robots" content="noindex">
<link rel="canonical" href="{site}{target}">
<meta http-equiv="refresh" content="0; url={target}">
<script>location.replace("{target}" + location.search + location.hash);</script>
</head>
<body>
<!-- GENERATED by tools/build.py: this address moved. -->
<p><a href="{target}">Queen's Gambit Zürich</a></p>
</body>
</html>
"""


def redirect_pages():
    for old, target in REDIRECTS.items():
        out = ROOT / old / "index.html"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(REDIRECT_PAGE.format(site=SITE, target=target))


if __name__ == "__main__":
    en_path = ROOT / "en" / "index.html"
    en_html = fill_regions(en_path.read_text(), "en")
    en_path.write_text(en_html)
    de_html = build_home_de()
    legal_pages(en_html, "en")
    legal_pages(de_html, "de")
    registration_pages(en_html, "en")
    registration_pages(de_html, "de")
    kids_pages(en_html, "en")
    kids_pages(de_html, "de")
    redirect_pages()
    sitemap(TODAY)
    print("Built: index.html (DE), impressum/, datenschutz/, winz/, kids/zollikon/, en/impressum/, en/privacy/, en/winz/, en/kids/zollikon/, redirects, sitemap.xml")
